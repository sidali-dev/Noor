/* @ds-bundle: {"format":4,"namespace":"Hilal","components":[{"name":"Button"},{"name":"PaperCard"},{"name":"ArchFrame"},{"name":"SkyHeader"},{"name":"Badge"},{"name":"TextField"},{"name":"Toggle"},{"name":"TabBar"},{"name":"Ornament"},{"name":"Icon"}]} */
(function () {
  var React = window.React;
  var h = React.createElement;
  function cx() { return Array.prototype.filter.call(arguments, Boolean).join(" "); }
  function assign(t) { for (var i = 1; i < arguments.length; i++) { var s = arguments[i]; if (s) for (var k in s) if (Object.prototype.hasOwnProperty.call(s, k)) t[k] = s[k]; } return t; }
  function omit(o, keys) { var r = {}; for (var k in o) if (keys.indexOf(k) < 0) r[k] = o[k]; return r; }

  /* ---------------- Icon (24px stroke set, inherits currentColor) ---------------- */
  var PATHS = {
    home: ["M4 11.5 12 5l8 6.5", "M6 10v9h12v-9", "M10 19v-5h4v5"],
    compass: ["M12 3a9 9 0 1 0 0 18a9 9 0 1 0 0-18z", "M15.5 8.5 13.4 13.4 8.5 15.5 10.6 10.6z"],
    calendar: ["M5 6h14v14H5z", "M5 10h14", "M9 3.5v4M15 3.5v4"],
    bookmark: ["M7 4h10v16l-5-3.5L7 20z"],
    settings: ["M12 9a3 3 0 1 0 0 6a3 3 0 1 0 0-6z", "M12 3v2.5M12 18.5V21M3 12h2.5M18.5 12H21M5.6 5.6l1.8 1.8M16.6 16.6l1.8 1.8M5.6 18.4l1.8-1.8M16.6 7.4l1.8-1.8"],
    moon: ["M15.5 4.2a8 8 0 1 0 4.3 11.3A6.5 6.5 0 0 1 15.5 4.2z"],
    star: ["M12 3l2 5.2 5.2 2-5.2 2L12 17.5l-2-5.3-5.2-2 5.2-2z"],
    search: ["M10.5 4a6.5 6.5 0 1 0 0 13a6.5 6.5 0 1 0 0-13z", "M15.5 15.5 20 20"],
    bell: ["M6 16V11a6 6 0 0 1 12 0v5l1.5 2h-15z", "M10 20.5a2 2 0 0 0 4 0"],
    check: ["M5 12.5 10 17 19 7"],
    alert: ["M12 4 21 19.5H3z", "M12 10v4.5", "M12 17h.01"],
    plus: ["M12 5v14M5 12h14"],
    book: ["M4 5.5c2.5-1 5.5-1 8 .8 2.5-1.8 5.5-1.8 8-.8V19c-2.5-1-5.5-1-8 .8-2.5-1.8-5.5-1.8-8-.8z", "M12 6.3v13.5"],
    tasbih: ["M12 3.5a6 6 0 1 0 0 12a6 6 0 1 0 0-12z", "M12 15.5v4", "M10 20.5h4", "M12 3.5v-.5"],
    clock: ["M12 3a9 9 0 1 0 0 18a9 9 0 1 0 0-18z", "M12 7.5V12l3 2"],
    alarm: ["M12 6a7 7 0 1 0 0 14a7 7 0 1 0 0-14z", "M12 9.5V13l2.2 1.5", "M5 4.5 3 6.5", "M19 4.5l2 2"],
    play: ["M8 5.5v13l10-6.5z"],
    pause: ["M8.5 5.5v13", "M15.5 5.5v13"],
    trash: ["M5 7h14", "M10 7V4.5h4V7", "M7 7l1 12.5h8L17 7", "M10.5 11v5M13.5 11v5"],
    edit: ["M5 19l1-4 9.5-9.5 3 3L9 18z", "M13.5 7.5l3 3"],
    "chevron-right": ["M9.5 6l6 6-6 6"],
    "chevron-left": ["M14.5 6l-6 6 6 6"],
    close: ["M6 6l12 12M18 6 6 18"],
    volume: ["M4 10v4h3.5L12 18V6L7.5 10z", "M15.5 9a4 4 0 0 1 0 6", "M18 6.5a7.5 7.5 0 0 1 0 11"],
    repeat: ["M5 11V9.5A2.5 2.5 0 0 1 7.5 7H19", "M16 4l3 3-3 3", "M19 13v1.5a2.5 2.5 0 0 1-2.5 2.5H5", "M8 20l-3-3 3-3"],
    more: ["M6 11a1 1 0 1 0 0 2a1 1 0 1 0 0-2z", "M12 11a1 1 0 1 0 0 2a1 1 0 1 0 0-2z", "M18 11a1 1 0 1 0 0 2a1 1 0 1 0 0-2z"],
    location: ["M12 21s-6.5-6-6.5-11a6.5 6.5 0 0 1 13 0c0 5-6.5 11-6.5 11z", "M12 7.5a2.5 2.5 0 1 0 0 5a2.5 2.5 0 1 0 0-5z"],
    "bell-off": ["M6 16V11a6 6 0 0 1 9.5-4.9", "M18 11v5l1.5 2H8", "M10 20.5a2 2 0 0 0 4 0", "M4 4l16 16"],
    info: ["M12 3a9 9 0 1 0 0 18a9 9 0 1 0 0-18z", "M12 11v5", "M12 8h.01"],
    sun: ["M12 8a4 4 0 1 0 0 8a4 4 0 1 0 0-8z", "M12 2.5v2M12 19.5v2M4.5 12h-2M21.5 12h-2M5.6 5.6l1.4 1.4M17 17l1.4 1.4M5.6 18.4 7 17M17 7l1.4-1.4"],
    reset: ["M4 12a8 8 0 1 0 2.3-5.6", "M4 4v4h4"],
    globe: ["M12 3a9 9 0 1 0 0 18a9 9 0 1 0 0-18z", "M3 12h18", "M12 3c2.5 2.5 3.8 5.5 3.8 9s-1.3 6.5-3.8 9c-2.5-2.5-3.8-5.5-3.8-9S9.5 5.5 12 3z"]
  };
  function Icon(props) {
    var size = props.size || 24;
    var d = PATHS[props.name] || PATHS.star;
    return h("svg", { className: cx("hl-icon", props.className), width: size, height: size, viewBox: "0 0 24 24", fill: "none",
      stroke: "currentColor", strokeWidth: props.strokeWidth || 1.6, strokeLinecap: "round", strokeLinejoin: "round",
      "aria-hidden": props.label ? undefined : "true", role: props.label ? "img" : undefined, "aria-label": props.label },
      d.map(function (p, i) { return h("path", { key: i, d: p }); }));
  }
  Icon.names = Object.keys(PATHS);

  /* ---------------- Button ---------------- */
  function Button(props) {
    var variant = props.variant || "primary";
    var rest = omit(props, ["variant", "size", "icon", "className", "children"]);
    return h("button", assign({ type: "button" }, rest, {
      className: cx("hl-btn", "hl-btn-" + variant, props.size === "sm" && "hl-btn-sm", props.className)
    }), props.icon ? h(Icon, { name: props.icon }) : null, props.children);
  }

  /* ---------------- PaperCard ---------------- */
  function PaperCard(props) {
    var e = props.elevation || 2;
    var rest = omit(props, ["elevation", "tone", "eyebrow", "title", "className", "children"]);
    return h("section", assign({}, rest, {
      className: cx("hl-card", "hl-card-e" + e, props.tone === "night" && "hl-card-night", props.className)
    }),
      props.eyebrow ? h("p", { className: "hl-card-eyebrow" }, props.eyebrow) : null,
      props.title ? h("h3", { className: "hl-card-title" }, props.title) : null,
      h("div", { className: "hl-card-body" }, props.children));
  }

  /* ---------------- ArchFrame (layered shadow box) ---------------- */
  // Light comes from straight above: every layer casts a short shadow downward onto the layer behind it.
  var ARCH = [[22, 88, 30], [52, 48, 32], [100, 14, 34], [148, 48, 34], [178, 88, 32], [200, 130, 30]];
  function archPath(d) {
    var sx = (200 - 2 * d) / 200, y0 = 14 + d * 1.15, sy = (240 - y0) / 226;
    var X = function (x) { return +(d + x * sx).toFixed(2); }, Y = function (y) { return +(y0 + (y - 14) * sy).toFixed(2); };
    var p = "M" + X(0) + " 240V" + Y(130);
    ARCH.forEach(function (a) { var r = +(a[2] * sx).toFixed(2); p += "A" + r + " " + r + " 0 0 1 " + X(a[0]) + " " + Y(a[1]); });
    return p + "V240Z";
  }
  function ring(c, x, y) { return "M" + (x - c) + " " + y + "a" + c + " " + c + " 0 1 0 " + 2 * c + " 0a" + c + " " + c + " 0 1 0 " + -2 * c + " 0Z"; }
  var INSETS = { 1: [0, 13], 2: [0, 10, 19], 3: [0, 8, 15, 21] };
  var STARS = [[46, 58, 2.6], [154, 54, 2.2], [54, 156, 1.8], [148, 160, 2.2], [38, 130, 1.6], [164, 134, 1.8], [78, 44, 1.4], [124, 40, 1.4]];
  function star(x, y, r, k) {
    var d = "M" + x + " " + (y - r * 2) + "L" + (x + r * .55) + " " + (y - r * .55) + "L" + (x + r * 2) + " " + y + "L" + (x + r * .55) + " " + (y + r * .55) +
      "L" + x + " " + (y + r * 2) + "L" + (x - r * .55) + " " + (y + r * .55) + "L" + (x - r * 2) + " " + y + "L" + (x - r * .55) + " " + (y - r * .55) + "Z";
    return h("path", { key: k, className: "star", d: d });
  }
  var archSeq = 0;
  function ArchFrame(props) {
    var uid = React.useRef("hla" + (++archSeq)).current;
    var width = props.width || 280;
    var show = function (k) { return props[k] === undefined ? true : props[k]; };
    var layers = INSETS[props.layers] ? props.layers : 3;
    var ins = INSETS[layers];
    var win = archPath(ins[ins.length - 1]);
    var cast = "url(#" + uid + "-c)", castDeep = "url(#" + uid + "-cd)", wash = "url(#" + uid + "-w)";
    var k = [];
    // defs: light wash, moon glow, two cast shadows, window clip
    k.push(h("defs", { key: "defs" },
      h("linearGradient", { id: uid + "-w", gradientUnits: "userSpaceOnUse", x1: 0, y1: 10, x2: 0, y2: 250 }, h("stop", { offset: 0, className: "w-top" }), h("stop", { offset: 1, className: "w-bot" })),
      h("radialGradient", { id: uid + "-g" }, h("stop", { offset: 0, className: "g-in" }), h("stop", { offset: 1, className: "g-out" })),
      h("filter", { id: uid + "-c", x: "-20%", y: "-20%", width: "140%", height: "160%" }, h("feDropShadow", { className: "hl-cast", dx: 0, dy: 1.4, stdDeviation: 1.3 })),
      h("filter", { id: uid + "-cd", x: "-20%", y: "-20%", width: "140%", height: "160%" }, h("feDropShadow", { className: "hl-cast", dx: 0, dy: 2.6, stdDeviation: 2.4 })),
      h("clipPath", { id: uid + "-k" }, h("path", { d: win }))));
    // 1. the night window and everything seen through it
    var sky = [h("path", { key: "win", className: "window", d: win })];
    if (show("stars")) STARS.forEach(function (s, i) { sky.push(star(s[0], s[1], s[2], "s" + i)); });
    if (show("moon")) { sky.push(h("circle", { key: "m", className: "moon", cx: 100, cy: 62, r: 13 })); sky.push(h("circle", { key: "mc", className: "window", cx: 105.5, cy: 57, r: 11.5 })); }
    if (show("moon") && show("glow")) sky.push(h("circle", { key: "glow", cx: 100, cy: 62, r: 46, fill: "url(#" + uid + "-g)" }));
    if (show("skyline")) {
      var mins = [];
      [70, 130].forEach(function (x, i) {
        mins.push(h("rect", { key: "mt" + i, x: x - 3.5, y: 150, width: 7, height: 100 }));
        mins.push(h("rect", { key: "mb" + i, x: x - 6, y: 163, width: 12, height: 2.5 }));
        mins.push(h("circle", { key: "mh" + i, cx: x, cy: 150, r: 4.5 }));
        mins.push(h("rect", { key: "ms" + i, x: x - .7, y: 139, width: 1.4, height: 9 }));
      });
      sky.push(h("g", { key: "mins", className: "paper-back", filter: cast }, mins));
      sky.push(h("rect", { key: "wall", className: "paper-back", filter: cast, x: 0, y: 200, width: 200, height: 50 }));
      sky.push(h("g", { key: "domes", className: "paper", filter: cast },
        [[44, 198], [156, 198]].map(function (d, i) { return h("g", { key: i }, h("circle", { cx: d[0], cy: d[1], r: 22 }), h("rect", { x: d[0] - 22, y: d[1], width: 44, height: 50 }), h("rect", { x: d[0] - .7, y: d[1] - 31, width: 1.4, height: 10 })); })));
    }
    k.push(h("g", { key: "sky", clipPath: "url(#" + uid + "-k)" }, sky));
    // 2. paper frames, innermost (furthest back) first; each casts onto the one behind it
    for (var i = ins.length - 2; i >= 0; i--) {
      k.push(h("path", { key: "r" + i, fill: wash, fillRule: "evenodd", filter: i === 0 ? castDeep : cast, d: archPath(ins[i]) + archPath(ins[i + 1]) }));
    }
    // 3. cloud scroll: back row, then front row, hiding the base
    if (show("clouds")) {
      var back = [[10, 200, 18], [46, 192, 22], [86, 196, 20], [126, 190, 22], [166, 196, 20], [196, 202, 16]];
      var front = [[-4, 214, 14], [26, 210, 18], [62, 212, 19], [100, 208, 21], [138, 212, 19], [174, 210, 18], [204, 215, 14]];
      var under = [[8, 226, 12], [36, 228, 13], [66, 227, 13], [96, 229, 13], [126, 227, 13], [156, 228, 13], [186, 226, 12]];
      k.push(h("g", { key: "cb", className: "paper-back", filter: cast }, back.map(function (c, j) { return h("circle", { key: j, cx: c[0], cy: c[1], r: c[2] }); })));
      k.push(h("g", { key: "cf", className: "paper", filter: cast },
        h("rect", { x: -2, y: 210, width: 204, height: 32 }),
        front.concat(under).map(function (c, j) { return h("circle", { key: j, cx: c[0], cy: c[1], r: c[2] }); })));
      k.push(h("g", { key: "sw", className: "swirl" }, [[26, 212, 9], [100, 210, 11], [174, 212, 9]].map(function (s, j) {
        return h("path", { key: j, d: "M" + (s[0] - s[2]) + " " + s[1] + "a" + s[2] + " " + s[2] + " 0 1 1 " + s[2] + " " + s[2] * .6 });
      })));
    }
    // 4. lace border, the front-most layer
    if (show("lace")) {
      var lp = "M-16 262V246", holes = "";
      for (var x = -16; x < 216; x += 16) {
        lp += "a8 8 0 0 1 16 0";
        holes += ring(2.4, x + 8, 246.5) + (x + 16 < 216 ? ring(1.2, x + 16, 255) : "");
      }
      k.push(h("path", { key: "lace", className: "paper", fillRule: "evenodd", filter: castDeep, d: lp + "V262Z" + holes }));
    }
    return h("figure", { className: cx("hl-arch", props.className), style: assign({ width: width }, props.style), role: props.label ? "img" : undefined, "aria-label": props.label },
      h("svg", { className: "hl-arch-svg", viewBox: "-20 0 240 266", "aria-hidden": "true" }, k),
      props.children ? h("div", { className: "hl-arch-content", style: props.contentTop ? { top: props.contentTop } : null }, props.children) : null);
  }

  /* ---------------- SkyHeader (full-width shadow-box header with a scene per feature) ---------------- */
  var skySeq = 0;
  function star4(x, y, r, key) {
    var q = r * .55;
    return h("path", { key: key, className: "star", d: "M" + x + " " + (y - 2 * r) + "L" + (x + q) + " " + (y - q) + "L" + (x + 2 * r) + " " + y + "L" + (x + q) + " " + (y + q) + "L" + x + " " + (y + 2 * r) + "L" + (x - q) + " " + (y + q) + "L" + (x - 2 * r) + " " + y + "L" + (x - q) + " " + (y - q) + "Z" });
  }
  function valance(y, r, step, phase) {
    var d = "M-20 -20H410V" + y;
    for (var x = 410 - phase; x > -20; x -= step) d += "A" + r + " " + r + " 0 0 1 " + (x - step) + " " + y;
    return d + "Z";
  }
  // Scenes are drawn on the left half (x 0–200) with their base at y 210; the header mirrors them for skylineSide="right".
  function sceneMosque(cast, deep, wash) {
    return [
      h("g", { key: "back", className: "scene-back", filter: cast },
        h("rect", { x: -10, y: 168, width: 214, height: 60 }),
        h("circle", { cx: 160, cy: 168, r: 15 }), h("rect", { x: 145, y: 168, width: 30, height: 40 }),
        h("circle", { cx: 6, cy: 174, r: 12 })),
      h("g", { key: "mins", fill: wash, filter: cast },
        [32, 128].map(function (x, i) {
          return h("g", { key: i },
            h("rect", { x: x - 4.5, y: 98, width: 9, height: 130 }),
            h("rect", { x: x - 8, y: 116, width: 16, height: 3.5 }), h("rect", { x: x - 7, y: 144, width: 14, height: 3 }),
            h("path", { d: "M" + (x - 5) + " 98L" + x + " 80L" + (x + 5) + " 98Z" }),
            h("rect", { x: x - .75, y: 70, width: 1.5, height: 11 }));
        })),
      h("g", { key: "dome", fill: wash, filter: deep },
        h("circle", { cx: 80, cy: 150, r: 34 }), h("rect", { x: 46, y: 150, width: 68, height: 70 }),
        h("rect", { x: 79.25, y: 102, width: 1.5, height: 14 }), h("circle", { cx: 80, cy: 100, r: 3 })),
      h("path", { key: "door", className: "window", d: "M71 214V184a9 9 0 0 1 18 0V214Z" }),
      h("path", { key: "win1", className: "window", d: "M54 170v-8a4 4 0 0 1 8 0v8Z" }),
      h("path", { key: "win2", className: "window", d: "M98 170v-8a4 4 0 0 1 8 0v8Z" })
    ];
  }
  function sceneKaaba(cast, deep, wash) {
    var arches = [];
    for (var x = -2, i = 0; x < 200; x += 18, i++) arches.push(h("path", { key: i, className: "window", d: "M" + (x + 4) + " 196V186a5 5 0 0 1 10 0V196Z" }));
    return [
      h("g", { key: "back", className: "scene-back", filter: cast },
        h("rect", { x: -10, y: 172, width: 214, height: 60 })),
      h("g", { key: "arc" }, arches),
      h("g", { key: "kaaba", filter: deep },
        h("path", { className: "scene-back", d: "M56 120L84 110L150 110L124 120Z" }),
        h("path", { className: "kaaba-side", d: "M124 120L150 110L150 188L124 200Z" }),
        h("rect", { className: "window", x: 56, y: 120, width: 68, height: 80 }),
        h("path", { className: "brass", d: "M56 134H124V143H56Z" }),
        h("path", { className: "brass", d: "M124 134L150 124V133L124 143Z" }),
        h("rect", { className: "brass", x: 100, y: 156, width: 13, height: 30, rx: 1.5 }),
        h("path", { className: "edge", d: "M56 120L84 110L150 110L150 188L124 200H56Z M124 120L150 110 M124 120V200 M56 120H124" })),
      h("ellipse", { key: "floor", fill: wash, filter: cast, cx: 100, cy: 212, rx: 90, ry: 12 })
    ];
  }
  function sceneQuran(cast, deep, wash) {
    var lines = [];
    [128, 136, 144].forEach(function (y, i) {
      lines.push(h("path", { key: "l" + i, d: "M44 " + (y + 4) + "C58 " + (y - 3) + " 74 " + (y - 3) + " 88 " + (y + 3) }));
      lines.push(h("path", { key: "r" + i, d: "M92 " + (y + 3) + "C106 " + (y - 3) + " 122 " + (y - 3) + " 136 " + (y + 4) }));
    });
    return [
      h("g", { key: "stand", className: "scene-back", filter: cast },
        h("path", { d: "M44 156L120 222L132 214L60 150Z" }), h("path", { d: "M136 156L60 222L48 214L120 150Z" }),
        h("rect", { x: 30, y: 204, width: 120, height: 10, rx: 5 })),
      h("g", { key: "cover", className: "brass", filter: cast },
        h("path", { d: "M90 116C70 104 42 108 26 120L36 166C54 156 76 156 90 164C104 156 126 156 144 166L154 120C138 108 110 104 90 116Z" })),
      h("g", { key: "pages", fill: wash, filter: deep },
        h("path", { d: "M90 118C72 108 48 111 32 122L41 160C57 151 76 151 90 158Z" }),
        h("path", { d: "M90 118C108 108 132 111 148 122L139 160C123 151 104 151 90 158Z" })),
      h("g", { key: "lines", className: "lines" }, lines),
      h("path", { key: "spine", className: "spine", d: "M90 118V158" })
    ];
  }
  function sceneTasbih(cast, deep, wash) {
    var beads = [], cx0 = 96, cy0 = 70, rx = 46, ry = 70;
    for (var i = 0; i <= 20; i++) {
      var a = Math.PI * i / 20;
      beads.push(h("circle", { key: "e" + i, cx: +(cx0 + rx * Math.cos(a)).toFixed(1), cy: +(cy0 + ry * Math.sin(a)).toFixed(1), r: 5.6 }));
    }
    for (var j = 1; j <= 5; j++) {
      beads.push(h("circle", { key: "a" + j, cx: +(cx0 + rx + j * 1.2).toFixed(1), cy: cy0 - j * 13, r: 5.6 }));
      beads.push(h("circle", { key: "b" + j, cx: +(cx0 - rx - j * 1.2).toFixed(1), cy: cy0 - j * 13, r: 5.6 }));
    }
    return [
      h("path", { key: "string", className: "string", d: "M" + (cx0 - rx - 7) + " 0L" + (cx0 - rx) + " " + cy0 + "A" + rx + " " + ry + " 0 0 0 " + (cx0 + rx) + " " + cy0 + "L" + (cx0 + rx + 7) + " 0" }),
      h("g", { key: "beads", fill: wash, filter: cast }, beads),
      h("g", { key: "imam", className: "brass", filter: deep },
        h("circle", { cx: cx0, cy: cy0 + ry + 10, r: 8 }),
        h("rect", { x: cx0 - 3, y: cy0 + ry + 16, width: 6, height: 12, rx: 2 }),
        h("path", { d: "M" + (cx0 - 7) + " " + (cy0 + ry + 46) + "L" + (cx0 - 3) + " " + (cy0 + ry + 27) + "H" + (cx0 + 3) + "L" + (cx0 + 7) + " " + (cy0 + ry + 46) + "Z" }))
    ];
  }
  var SCENES = { mosque: sceneMosque, kaaba: sceneKaaba, quran: sceneQuran, tasbih: sceneTasbih };

  function SkyHeader(props) {
    var uid = React.useRef("hls" + (++skySeq)).current;
    var H = props.height || 210, off = H - 210;
    var show = function (k) { return props[k] === undefined ? true : props[k]; };
    var mirror = props.skylineSide === "right";
    var scene = props.scene || (props.skyline === false ? "none" : "mosque");
    var cast = "url(#" + uid + "-c)", deep = "url(#" + uid + "-d)", wash = "url(#" + uid + "-w)";
    var mx = function (x) { return mirror ? 390 - x : x; };
    var flip = mirror ? "translate(390 " + off + ") scale(-1 1)" : "translate(0 " + off + ")";
    var k = [];
    k.push(h("defs", { key: "defs" },
      h("linearGradient", { id: uid + "-w", gradientUnits: "userSpaceOnUse", x1: 0, y1: 70, x2: 0, y2: 215 }, h("stop", { offset: 0, className: "w-top" }), h("stop", { offset: 1, className: "w-bot" })),
      h("linearGradient", { id: uid + "-s", gradientUnits: "userSpaceOnUse", x1: 0, y1: 70, x2: 0, y2: 215 }, h("stop", { offset: 0, className: "s-top" }), h("stop", { offset: 1, className: "s-bot" })),
      h("radialGradient", { id: uid + "-g" }, h("stop", { offset: 0, className: "g-in" }), h("stop", { offset: 1, className: "g-out" })),
      h("filter", { id: uid + "-c", x: "-10%", y: "-20%", width: "120%", height: "160%" }, h("feDropShadow", { className: "hl-cast", dx: 0, dy: 1.6, stdDeviation: 1.5 })),
      h("filter", { id: uid + "-d", x: "-10%", y: "-20%", width: "120%", height: "160%" }, h("feDropShadow", { className: "hl-cast", dx: 0, dy: 3, stdDeviation: 2.8 }))));
    // 1. sky, glow, stars, moon
    k.push(h("rect", { key: "w", className: "window", x: -20, y: -20, width: 430, height: H + 40 }));
    if (show("moon")) k.push(h("circle", { key: "gl", cx: mx(182), cy: 46, r: 58, fill: "url(#" + uid + "-g)" }));
    if (show("stars")) [[22, 48, 1.8], [150, 30, 1.5], [66, 70, 2.2], [214, 92, 1.3], [120, 62, 1.4], [16, 108, 1.4], [236, 40, 1.2], [176, 116, 1.6]].forEach(function (s, i) { k.push(star4(mx(s[0]), s[1], s[2], "s" + i)); });
    if (show("moon")) {
      k.push(h("circle", { key: "m", className: "moon", cx: mx(182), cy: 46, r: 13 }));
      k.push(h("circle", { key: "mc", className: "window", cx: mx(182) + (mirror ? -5.5 : 5.5), cy: 41.5, r: 11.5 }));
    }
    // 2. far dunes inside the sky, then the scene
    var low = [h("path", { key: "far", className: "far", filter: cast, d: "M-20 230V178C30 160 80 168 128 178S226 160 276 172S356 164 410 176V230Z" })];
    var NUDGE = { mosque: [14, -6], kaaba: [10, -20], quran: [12, -24], tasbih: [10, -4] };
    if (SCENES[scene]) low.push(h("g", { key: "scene", transform: "translate(" + NUDGE[scene][0] + " " + NUDGE[scene][1] + ")" }, SCENES[scene](cast, deep, "url(#" + uid + "-s)")));
    // 3. cloud scroll: back row, front row the colour of the page
    if (show("clouds")) {
      var back = [], front = [];
      for (var x = -14, i = 0; x < 410; x += 42, i++) back.push(h("circle", { key: "b" + i, cx: x, cy: 188 + (i % 2) * 5, r: 22 + (i % 3) * 3 }));
      for (var x2 = 6, j = 0; x2 < 410; x2 += 50, j++) front.push(h("circle", { key: "f" + j, cx: x2, cy: 204 + (j % 2) * 3, r: 21 + (j % 2) * 4 }));
      front.push(h("rect", { key: "fr", x: -20, y: 206, width: 430, height: 30 }));
      low.push(h("g", { key: "cb", fill: wash, filter: cast }, back));
      low.push(h("g", { key: "cf", className: "ground", filter: deep }, front));
      low.push(h("g", { key: "sw", className: "swirl" }, [[56, 202, 9], [206, 200, 10], [356, 203, 8]].map(function (s, n) {
        return h("path", { key: n, d: "M" + (s[0] - s[2]) + " " + s[1] + "a" + s[2] + " " + s[2] + " 0 1 1 " + s[2] + " " + s[2] * .6 });
      })));
    }
    k.push(h("g", { key: "low", transform: flip }, low));
    // 4. scalloped paper layers hanging across the top, front-most
    if (show("valance")) {
      k.push(h("path", { key: "v2", className: "paper-back", filter: cast, d: valance(22, 12, 22, 11) }));
      k.push(h("path", { key: "v1", fill: wash, filter: deep, d: valance(12, 16, 30, 0) }));
    }
    return h("header", { className: cx("hl-sky", props.className), style: assign({ height: H }, props.style), "aria-label": props.label },
      h("svg", { className: "hl-sky-svg", viewBox: "0 0 390 " + H, preserveAspectRatio: "xMidYMax slice", "aria-hidden": "true" }, k),
      props.children ? h("div", { className: "hl-sky-content" }, props.children) : null);
  }

  /* ---------------- Badge ---------------- */
  function Badge(props) {
    var tone = props.tone || "neutral";
    var icon = props.icon || (tone === "success" ? "check" : tone === "danger" ? "alert" : null);
    return h("span", { className: cx("hl-badge", "hl-badge-" + tone, props.className) }, icon ? h(Icon, { name: icon, size: 12, strokeWidth: 2 }) : null, props.children);
  }

  /* ---------------- TextField ---------------- */
  var fieldSeq = 0;
  function TextField(props) {
    var idRef = React.useRef(props.id || "hl-field-" + (++fieldSeq));
    var id = idRef.current;
    var rest = omit(props, ["label", "hint", "error", "className", "id"]);
    var msg = props.error || props.hint;
    return h("div", { className: cx("hl-field", props.error && "hl-field-error", props.className) },
      props.label ? h("label", { className: "hl-field-label", htmlFor: id }, props.label) : null,
      h("input", assign({ className: "hl-field-input", id: id, "aria-invalid": props.error ? "true" : undefined, "aria-describedby": msg ? id + "-msg" : undefined }, rest)),
      msg ? h("span", { className: "hl-field-hint", id: id + "-msg" }, props.error ? h(Icon, { name: "alert", size: 14, strokeWidth: 2 }) : null, props.error ? " " : null, msg) : null);
  }

  /* ---------------- Toggle ---------------- */
  function Toggle(props) {
    var controlled = props.checked !== undefined;
    var st = React.useState(!!props.defaultChecked);
    var on = controlled ? props.checked : st[0];
    return h("label", { className: cx("hl-toggle", props.className) },
      h("input", { type: "checkbox", role: "switch", checked: on, disabled: props.disabled,
        onChange: function (e) { if (!controlled) st[1](e.target.checked); if (props.onChange) props.onChange(e.target.checked); } }),
      h("span", { className: "hl-toggle-track", "aria-hidden": "true" }, h("span", { className: "hl-toggle-thumb" })),
      props.label ? h("span", null, props.label) : null);
  }

  /* ---------------- TabBar ---------------- */
  function TabBar(props) {
    var items = props.items || [];
    var st = React.useState(props.defaultActive || (items[0] && items[0].id));
    var active = props.active !== undefined ? props.active : st[0];
    return h("nav", { className: cx("hl-tabbar", props.className), "aria-label": props.label || "Main" },
      items.map(function (it) {
        return h("button", { key: it.id, type: "button", className: "hl-tab", "aria-current": it.id === active ? "page" : undefined,
          onClick: function () { if (props.active === undefined) st[1](it.id); if (props.onChange) props.onChange(it.id); } },
          h(Icon, { name: it.icon }), h("span", null, it.label));
      }));
  }

  /* ---------------- Ornament ---------------- */
  function Ornament(props) {
    return h("div", { className: cx("hl-ornament", props.className), role: "separator" },
      props.label ? h("span", { className: "hl-ornament-label" }, props.label)
        : h("svg", { viewBox: "0 0 24 24", "aria-hidden": "true" },
          h("g", { fill: "currentColor" },
            h("rect", { x: 5, y: 5, width: 14, height: 14 }),
            h("rect", { x: 5, y: 5, width: 14, height: 14, transform: "rotate(45 12 12)" }))));
  }

  var api = { Button: Button, PaperCard: PaperCard, ArchFrame: ArchFrame, SkyHeader: SkyHeader, Badge: Badge, TextField: TextField, Toggle: Toggle, TabBar: TabBar, Ornament: Ornament, Icon: Icon };
  window.Hilal = assign(window.Hilal || {}, api);
})();
